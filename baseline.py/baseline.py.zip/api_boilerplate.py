#!/usr/bin/env python3
""" basic boilerplate for cpapi SDK """
import sys
from cpapi import APIClient, APIClientArgs


def main():
    api_server = "192.168.44.220"
    username = "admin"
    password = "vpn123"

    client_args = APIClientArgs(server=api_server)
    with APIClient(client_args) as client:

        login = client.login(username, password)
        if not login.success:
            print(login.error_message)
            sys.exit(1)

        ###########################
        ### YOUR CODE GOES HERE ###
        ###########################

        # hosts = client.api_query("show-hosts").data
        # [print(host["name"]) for host in hosts]
        #
        # set_session = client.api_call("set-session", payload={"description": "test session"})
        # print(f"Changed description: {set_session.data['description']}" if set_session.success else set_session.error_message)

        publish = client.api_call("publish")
        if not publish.success:
            print(publish.error_message)


if __name__ == "__main__":
    main()
